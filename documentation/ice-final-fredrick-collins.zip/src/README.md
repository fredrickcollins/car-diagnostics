


NOTE:
This website will not run just by opening index.html
You can start the node server by running 'node index.js'
First run 'npm install' to collect dependencies from package.json

Alternatively, visit the live version at https://ice-reader.herokuapp.com/index.html

Users setting up their own ice reader will have to install hostapd and 
setup a wireless access point, then connect and visit 192.168.1.1:8080/index.html

Best wishes!